/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import javafx.scene.control.Alert;


/**
 *
 * @author saif_kridane
 */
public class event {
    
    private String titre;
    private String desE;
    private String date;
    private int prix;
    private String Adresse;
    private int nbrTotal;
    private int nbrRestant;
    private int idcoach;
        private int idE;
    public event()
    {
        
    }

    public event(String titre, String desE, String date, int prix, String Adresse, int nbrTotal, int nbrRestant,int idcoach, int idE) {
        this.titre = titre;
        this.desE = desE;
        this.date = date;
        this.prix = prix;
        this.Adresse = Adresse;
        this.nbrTotal = nbrTotal;
        this.nbrRestant = nbrRestant;
        this.idcoach = idcoach;
        this.idE = idE;
    }
    

    public int getIdE() {
        return idE;
    }
    
    public int getIdcoach() {
        return idcoach;
    }

    public String getTitre() {
        return titre;
    }

    public String getDesE() {
        return desE;
    }

    public String getDate() {
        return date;
    }

    public int getPrix() {
        return prix;
    }
    
    public String getAdresse() {
        return Adresse;
    }
    
    public int getNbrTotal() {
        return nbrTotal;
    }
    
    public int getNbrRestant() {
        return nbrRestant;
    }

    public void setIdE(int idE) {
        this.idE = idE;
    }
    
    public void setIdcoach(int idcoach) {
        this.idcoach = idcoach;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public void setDesE(String desE) {
        this.desE = desE;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }

     public void setAdresse(String Adresse) {
        this.Adresse = Adresse;
    }
     
      public void setNbrTotal(int nbrTotal) {
        this.nbrTotal = nbrTotal;
    }
      
       public void setNbrRestant (int nbrRestant) {
        this.nbrRestant = nbrRestant;
    }
    @Override
    public String toString() {
        return "event{" + "idE=" + idE + "idcoach=" + idcoach + ", titre=" + titre + ", desE=" + desE + ", date=" + date + ", prix=" + prix + ", Adresse=" + Adresse + ", nbrTotal=" + nbrTotal + ", nbrRestant=" + nbrRestant + '}';
    }
    
    public static boolean isNull(String text){
     if(text == ""){
       return true; //null
     }
     

Alert alert = new Alert(Alert.AlertType.ERROR);
alert.setTitle("Error Dialog");
alert.setHeaderText(null);
alert.setContentText("Ooops, you have a empty testfield(s)!");

alert.showAndWait();
return false ;
//n'est pas vide
   }
    
    
}
 