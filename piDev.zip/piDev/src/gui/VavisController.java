/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import entities.avis;
import entities.event;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author saif_kridane
 */
public class VavisController implements Initializable {

    
    @FXML
    private TableColumn<avis, String> colTitre;
    @FXML
    private TableColumn<avis, String> colDate;
    @FXML
    private TableColumn<avis, String> colTypeavis;
    @FXML
    private TableColumn<avis, Integer> colNote;
    @FXML
    private TableColumn<avis, String> colNomclient;
    @FXML
    private TableColumn<avis, String> colEmail;
    @FXML
    private TableColumn<avis, String> coldes;
    @FXML
    private Button btnDelete;
    @FXML
    private TextField tfrechercher;

    
      private final ObservableList<avis> d = FXCollections.observableArrayList();
    @FXML
    private TableView<avis> tvavis;
    @FXML
    private Button tfpdf;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        showavis();
        rechercherT();
    }    

    @FXML
    private void handleButtonAction(ActionEvent event) {
        
    
    avis avis = tvavis.getSelectionModel().getSelectedItem();
    
            
         
        
System.out.println(avis.getIdAvis()); 


Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
alert.setTitle("Confirmation Dialog");
alert.setHeaderText("Look, a Confirmation Dialog");
alert.setContentText("Are you ok with this?");

Optional<ButtonType> result = alert.showAndWait();
if (result.get() == ButtonType.OK){
    
       String query = "DELETE FROM avis WHERE IDavis =" + avis.getIdAvis() + "";
     
       executeQuery(query);
       rechercherT();
        
} else {
    // ... user chose CANCEL or closed the dialog
}

/**
      
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("ERROR:");
        alert.setHeaderText("No selection was made.");
        alert.setContentText("You have not selected an item to delete. Please try again.");
        alert.showAndWait();
        
   */
    
        }

        private void executeQuery(String query) {
        Connection conn = getConnection();
       
        Statement st;
        try{
            st = conn.createStatement();
            st.executeUpdate(query);
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
        
         public void rechercherT() {
    FilteredList<avis> filteredData = new FilteredList<>(d, b -> true);

                ObservableList<avis> list = getavisList();
                
               d.clear();
              d.addAll(list);
		// 2. Set the filter Predicate whenever the filter changes.
		tfrechercher.textProperty().addListener((observable, oldValue, newValue) -> {
			filteredData.setPredicate(avis -> {
				// If filter text is empty, display all persons.
				if (newValue == null || newValue.isEmpty()) return true;

				// Compare every table columns fields with lowercase filter text
				String lowerCaseFilter = newValue.toLowerCase();

				// Filter with all table columns
				if (avis.getTitre().toLowerCase().indexOf(lowerCaseFilter) != -1) return true; 
				else if (avis.getDateE().toLowerCase().indexOf(lowerCaseFilter) != -1) return true;

				else return false; // Does not match
			});
		});

		// 3. Wrap the FilteredList in a SortedList.
		SortedList<avis> sortedData = new SortedList<>(filteredData);

		// 4. Bind the SortedList comparator to the TableView comparator.
		// Otherwise, sorting the TableView would have no effect.
		sortedData.comparatorProperty().bind(tvavis.comparatorProperty());

		// 5. Add sorted (and filtered) data to the table.
		tvavis.setItems(sortedData);
}
    
   public Connection getConnection(){
        Connection conn;
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pidev", "root","root");
            return conn;
        }catch(Exception ex){
            System.out.println("Error: " + ex.getMessage());
            return null;
        }
    }
   
   
   public ObservableList<avis> getavisList(){
        ObservableList<avis> avisList = FXCollections.observableArrayList();
        Connection conn = getConnection();
        String query = "SELECT * from avis where Titre like '"+tfrechercher.getText()+"%'";
        Statement st;
        ResultSet rs;
        
        try{
            st = conn.createStatement();
            rs = st.executeQuery(query);
            avis avis;
            while(rs.next()){
                avis = new avis(rs.getString("Titre"), rs.getString("TypeAvis"), rs.getString("DateEvent"), rs.getInt("Note"), rs.getString("NomClient"),rs.getString("Email"), rs.getString("Des"), rs.getInt("IDavis"));
                avisList.add(avis);
            }
                
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return avisList;
    }
    
     public void showavis(){
        ObservableList<avis> list = getavisList();
        
        colTitre.setCellValueFactory(new PropertyValueFactory<avis, String>("Titre"));
        colTypeavis.setCellValueFactory(new PropertyValueFactory<avis, String>("typeAvis"));
        colDate.setCellValueFactory(new PropertyValueFactory<avis, String>("DateE"));
        colNote.setCellValueFactory(new PropertyValueFactory<avis, Integer>("Note"));
        colNomclient.setCellValueFactory(new PropertyValueFactory<avis, String>("nomClient"));
        colEmail.setCellValueFactory(new PropertyValueFactory<avis, String>("email"));
        coldes.setCellValueFactory(new PropertyValueFactory<avis, String>("Des"));
        
        
        tvavis.setItems(list);
         
    }

    @FXML
    private void pdfs() throws SQLException, ClassNotFoundException 
    {
     
        try {
           Class.forName("com.mysql.jdbc.Driver");
               Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pidev", "root", "root");
  Statement stmt = conn.createStatement();
                    /* Define the SQL query */
                    
                 
                    ResultSet query_set = stmt.executeQuery("SELECT * From avis");
                   
                    /* Step-2: Initialize PDF documents - logical objects */
                    Document my_pdf_report = new Document();
                    PdfWriter.getInstance(my_pdf_report, new FileOutputStream("/Users/saif_kridane/Desktop/pdf_report_from_sql_using_java.pdf"));
                    my_pdf_report.open();            
                    //we have four columns in our table
                    PdfPTable my_report_table = new PdfPTable(7);
                    //create a cell object
                    PdfPCell table_cell;

                    while (query_set.next()) {                
                                    String Titre = query_set.getString("Titre");
                                    table_cell=new PdfPCell(new Phrase(Titre));
                                    my_report_table.addCell(table_cell);
                                    String TypeAvis=query_set.getString("TypeAvis");
                                    table_cell=new PdfPCell(new Phrase(TypeAvis));
                                    my_report_table.addCell(table_cell);
                                    String DateEvent=query_set.getString("DateEvent");
                                    table_cell=new PdfPCell(new Phrase(DateEvent));
                                    my_report_table.addCell(table_cell);
                                    String Note=query_set.getString("Note");
                                    table_cell=new PdfPCell(new Phrase(Note));
                                    my_report_table.addCell(table_cell);
                                    String NomClient=query_set.getString("NomClient");
                                    table_cell=new PdfPCell(new Phrase(NomClient));
                                    my_report_table.addCell(table_cell);
                                    String Email=query_set.getString("Email");
                                    table_cell=new PdfPCell(new Phrase(Email));
                                    my_report_table.addCell(table_cell);
                                    String Description=query_set.getString("Des");
                                    table_cell=new PdfPCell(new Phrase(Description));
                                    my_report_table.addCell(table_cell);
                                    }
                    /* Attach report table to PDF */
                    my_pdf_report.add(my_report_table);                       
                    my_pdf_report.close();

                    /* Close all DB related objects */
                    query_set.close();
                    stmt.close(); 
                    conn.close();               



    } catch (FileNotFoundException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
    } catch (DocumentException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
    }
}
    
}
