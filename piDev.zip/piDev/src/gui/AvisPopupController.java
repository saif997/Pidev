/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import entities.avis;
import entities.event;
import static gui.EventController.sendMail;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import gui.Entity2Controller;
import javafx.scene.control.TableView;

/**
 * FXML Controller class
 *
 * @author saif_kridane
 */
public class AvisPopupController implements Initializable {

    @FXML
    private RadioButton fxReclamation;
    @FXML
    private RadioButton fxRemerciement;
    @FXML
    private Button fxsend;
    @FXML
    private TextField fxNomE;
    @FXML
    private TextField fxDateE;
    @FXML
    private TextField fxNote;
    @FXML
    private TextField fxNomC;
    @FXML
    private TextField fxEmail;
    @FXML
    private TextArea fxDes;
    
  
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //TODO
        
        
                
        
    }

    @FXML
    private void send(ActionEvent event) {
        int j = 0;
        Stage stage;
        String rbdtext;
        String[] badWord = {"kill", "fuck", "stupid", "asshole", "sex", "racist", "war", "blood", "k*ll", "F*ck", "shit", "sh*t"};

        if (fxReclamation.isSelected()) {
            rbdtext = fxReclamation.getText();
        } else {
            rbdtext = fxRemerciement.getText();
        }

        if(fxDes.getText().contains("kill")||fxDes.getText().contains("fuck")||fxDes.getText().contains("stupid")||fxDes.getText().contains("racist")||fxDes.getText().contains("war")||fxDes.getText().contains("shit") ) {
           
        
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Dialog");
                alert.setHeaderText("Look, an Error Dialog");
                alert.setContentText("Ooops, you can say bad words in this section!");

                alert.showAndWait();
          
            
         
        }
        else {
            
        
        if (fxNomE.getText() == "" || rbdtext == "" || fxDateE.getText() == null || fxNote.getText() == "" || fxNomC.getText() == "" || fxEmail.getText() == "" || fxDes.getText() == "") {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText(null);
            alert.setContentText("Ooops, Your Textfiels(s) is Empty!");

            alert.showAndWait();
        } else {
            if (fxNote.getText().matches("^[0-9]+$")) {

                String query = "INSERT INTO avis(`Titre`, `TypeAvis`, `DateEvent`, `Note`, `NomClient`, `Email`, `Des`) VALUES ('" + fxNomE.getText() + "','" + rbdtext + "','" + fxDateE.getText() + "','"
                        + fxNote.getText() + "','" + fxNomC.getText() + "','" + fxEmail.getText() + "','" + fxDes.getText() + "')";
                executeQuery(query);

                stage = (Stage) fxsend.getScene().getWindow();
                stage.close();
                try {
                    sendMail(fxEmail.getText());
                } catch (Exception ex) {
                    Logger.getLogger(EventController.class.getName()).log(Level.SEVERE, null, ex);
                }

            } else {

                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error Dialog");
                alert.setHeaderText(null);
                alert.setContentText("Ooops, Please enter a correct number in int fields");

                alert.showAndWait();

            }
        }
}
    }

    private void executeQuery(String query) {
        Connection conn = getConnection();

        Statement st;
        try {
            st = conn.createStatement();
            st.executeUpdate(query);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public Connection getConnection() {
        Connection conn;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pidev", "root", "root");
            return conn;
        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
            return null;
        }
    }

}
