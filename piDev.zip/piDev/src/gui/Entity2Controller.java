/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;


import entities.event;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author saif_kridane
 */
public class Entity2Controller implements Initializable {

    @FXML
     TableView<event> tvevent;
    @FXML
    private TableColumn<event, String> colTitre;
    @FXML
    private TableColumn<event, String> colDate;
    @FXML
    private TableColumn<event, Integer> colPrix;
    @FXML
    private TableColumn<event, String> colAdresse;
    @FXML
    private TableColumn<event, Integer> colNbrTotal;
    @FXML
    private TableColumn<event, Integer> colNbrRestant;
    @FXML
    private TableColumn<event, Integer> colcoach;
    @FXML
    private TableColumn<event, String> colDes;
    @FXML
    private TextField tfrechercher;

    private final ObservableList<event> d = FXCollections.observableArrayList();
    @FXML
    private Button fxavis;
    @FXML
    private Button fxBack;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO

        showevent();
        rechercherT();
        
        

    }

    public void rechercherT() {
        FilteredList<event> filteredData = new FilteredList<>(d, b -> true);

        ObservableList<event> list = geteventList();

        d.clear();
        d.addAll(list);
        // 2. Set the filter Predicate whenever the filter changes.
        tfrechercher.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(event -> {
                // If filter text is empty, display all persons.
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                // Compare every table columns fields with lowercase filter text
                String lowerCaseFilter = newValue.toLowerCase();

                // Filter with all table columns
                if (event.getTitre().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true;
                } else if (event.getDate().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true;
                } else {
                    return false; // Does not match
                }
            });
        });

        // 3. Wrap the FilteredList in a SortedList.
        SortedList<event> sortedData = new SortedList<>(filteredData);

        // 4. Bind the SortedList comparator to the TableView comparator.
        // Otherwise, sorting the TableView would have no effect.
        sortedData.comparatorProperty().bind(tvevent.comparatorProperty());

        // 5. Add sorted (and filtered) data to the table.
        tvevent.setItems(sortedData);
    }

    public Connection getConnection() {
        Connection conn;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pidev", "root", "root");
            return conn;
        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
            return null;
        }
    }

    public ObservableList<event> geteventList() {
        ObservableList<event> eventList = FXCollections.observableArrayList();
        Connection conn = getConnection();
        String query = "SELECT * from evenement where Titre like '" + tfrechercher.getText() + "%'";
        Statement st;
        ResultSet rs;

        try {
            st = conn.createStatement();
            rs = st.executeQuery(query);
            event event;
            while (rs.next()) {
                event = new event(rs.getString("Titre"), rs.getString("DesEvent"), rs.getString("DateEvent"), rs.getInt("Prix"), rs.getString("Adresse"), rs.getInt("NbrTotal"), rs.getInt("NbrRestant"), rs.getInt("idcoach"), rs.getInt("IDevent"));
                eventList.add(event);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return eventList;
    }

    public void showevent() {
        ObservableList<event> list = geteventList();

        colTitre.setCellValueFactory(new PropertyValueFactory<event, String>("Titre"));
        colDes.setCellValueFactory(new PropertyValueFactory<event, String>("DesE"));
        colDate.setCellValueFactory(new PropertyValueFactory<event, String>("Date"));
        colPrix.setCellValueFactory(new PropertyValueFactory<event, Integer>("Prix"));
        colAdresse.setCellValueFactory(new PropertyValueFactory<event, String>("Adresse"));
        colNbrTotal.setCellValueFactory(new PropertyValueFactory<event, Integer>("NbrTotal"));
        colNbrRestant.setCellValueFactory(new PropertyValueFactory<event, Integer>("NbrRestant"));
        colcoach.setCellValueFactory(new PropertyValueFactory<event, Integer>("idcoach"));

        tvevent.setItems(list);

    }

    private void executeQuery(String query) {
        Connection conn = getConnection();

        Statement st;
        try {
            st = conn.createStatement();
            st.executeUpdate(query);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @FXML
    private void back(ActionEvent event) throws IOException {

        Stage stage;
        Parent root;

        stage = (Stage) fxBack.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("login.fxml"));

        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    public void avis() throws IOException {

        Stage stage = new Stage();
        Parent root;
       

        //stage = (Stage) btn1.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("AvisPopup.fxml"));
        stage.setScene(new Scene(root));
        stage.initOwner(fxavis.getScene().getWindow());
        stage.showAndWait();
        

    }

  
}
