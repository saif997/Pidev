/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;


import entities.event;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.controlsfx.control.textfield.TextFields;

/**
 * FXML Controller class
 *
 * @author saif_kridane
 */
public class EventController implements Initializable {

    private TableView<event> fxAfficher;
    private Button fxAjouter;
    private Button fxSupp;
    private TableColumn<event, String> fxDateAfficher;
    private TableColumn<event, Integer> fxPrixAfficher;
    private TableColumn<event, String> fxDesAfficher;
    private TableColumn<event, Integer> fxIdAfficher;
    private TableColumn<event, String> fxTitreAfficher;

    @FXML
    private TableView<event> tvevent;
    @FXML
    private TableColumn<event, String> colTitre;
    @FXML
    private TableColumn<event, String> colDate;
    @FXML
    private TableColumn<event, Integer> colPrix;
    @FXML
    private TableColumn<event, String> colDes;
    @FXML
    private Button btnInsert;
    @FXML
    private Button btnUpdate;
    @FXML
    private Button btnDelete;
    @FXML
    private TextField tfTitre;
    @FXML
    private TextArea tefDes;
    @FXML
    private DatePicker tfDate;
    @FXML
    private TextField tfPrix;
    private TextField tfId;
    @FXML
    private TextField tfrechercher;

    @FXML
    private TextField tfAdresse;
    @FXML
    private TextField tfTotal;
    @FXML
    private TextField tfRestant;

    @FXML
    private TextField tfCoach;

    private PreparedStatement pst;

    private final ObservableList<event> d = FXCollections.observableArrayList();

    @FXML
    private TableColumn<event, String> colAdresse;
    @FXML
    private TableColumn<event, Integer> colNbrTotal;
    @FXML
    private TableColumn<event, Integer> colNbrRestant;

    @FXML
    private TableColumn<event, Integer> colcoach;
    @FXML
    private Button btnGet;
    @FXML
    private Button fxBack;
    @FXML
    private Button btnavis;

    @FXML
    private void handleButtonAction(ActionEvent event) throws SQLException {

        if (event.getSource() == btnInsert) {
            insertRecord();
        } else if (event.getSource() == btnUpdate) {
            updateRecord();
        } else if (event.getSource() == btnDelete) {
            deleteButton();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO 

        showevent();
        rechercherT();

        String[] type = {"saif", "test", "1234", "sai", "azer", "achrag", "te", "tek", "tekwa", "tekwando", "bo", "box", "cr", "cra", "craf", "crafma",
             "word"};
        TextFields.bindAutoCompletion(tfrechercher, type);

    }

    public void rechercherT() {
        FilteredList<event> filteredData = new FilteredList<>(d, b -> true);

        ObservableList<event> list = geteventList();

        d.clear();
        d.addAll(list);
        // 2. Set the filter Predicate whenever the filter changes.
        tfrechercher.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(event -> {
                // If filter text is empty, display all persons.
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                // Compare every table columns fields with lowercase filter text
                String lowerCaseFilter = newValue.toLowerCase();

                // Filter with all table columns
                if (event.getTitre().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true;
                } else if (event.getDate().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true;
                } else {
                    return false; // Does not match
                }
            });
        });

        // 3. Wrap the FilteredList in a SortedList.
        SortedList<event> sortedData = new SortedList<>(filteredData);

        // 4. Bind the SortedList comparator to the TableView comparator.
        // Otherwise, sorting the TableView would have no effect.
        sortedData.comparatorProperty().bind(tvevent.comparatorProperty());

        // 5. Add sorted (and filtered) data to the table.
        tvevent.setItems(sortedData);
    }

    public Connection getConnection() {
        Connection conn;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pidev", "root", "root");
            return conn;
        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
            return null;
        }
    }

    public ObservableList<event> geteventList() {
        ObservableList<event> eventList = FXCollections.observableArrayList();
        Connection conn = getConnection();
        String query = "SELECT * from evenement where Titre like '" + tfrechercher.getText() + "%'";
        Statement st;
        ResultSet rs;

        try {
            st = conn.createStatement();
            rs = st.executeQuery(query);
            event event;
            while (rs.next()) {
                event = new event(rs.getString("Titre"), rs.getString("DesEvent"), rs.getString("DateEvent"), rs.getInt("Prix"), rs.getString("Adresse"), rs.getInt("NbrTotal"), rs.getInt("NbrRestant"), rs.getInt("idcoach"), rs.getInt("IDevent"));
                eventList.add(event);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return eventList;
    }

    public void showevent() {
        ObservableList<event> list = geteventList();

        colTitre.setCellValueFactory(new PropertyValueFactory<event, String>("Titre"));
        colDes.setCellValueFactory(new PropertyValueFactory<event, String>("DesE"));
        colDate.setCellValueFactory(new PropertyValueFactory<event, String>("Date"));
        colPrix.setCellValueFactory(new PropertyValueFactory<event, Integer>("Prix"));
        colAdresse.setCellValueFactory(new PropertyValueFactory<event, String>("Adresse"));
        colNbrTotal.setCellValueFactory(new PropertyValueFactory<event, Integer>("NbrTotal"));
        colNbrRestant.setCellValueFactory(new PropertyValueFactory<event, Integer>("NbrRestant"));
        colcoach.setCellValueFactory(new PropertyValueFactory<event, Integer>("idcoach"));

        tvevent.setItems(list);

    }

    private void insertRecord() {

        if (tfTitre.getText() == "" || tefDes.getText() == "" || tfDate.getValue() == null || tfPrix.getText() == "" || tfAdresse.getText() == "" || tfTotal.getText() == "" || tfRestant.getText() == "" || tfCoach.getText() == "") {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText(null);
            alert.setContentText("Ooops, Your Textfiels(s) is Empty!");

            alert.showAndWait();
        } else {

            if (tfPrix.getText().matches("^[0-9]+$") && tfTotal.getText().matches("^[0-9]+$") && tfRestant.getText().matches("^[0-9]+$") && tfCoach.getText().matches("^[0-9]+$")) {

                String query = "INSERT INTO evenement(`Titre`, `DesEvent`, `DateEvent`, `Prix`, `Adresse`, `NbrTotal`, `NbrRestant`, `idcoach`) VALUES ('" + tfTitre.getText() + "','" + tefDes.getText() + "','" + tfDate.getValue() + "','"
                        + tfPrix.getText() + "','" + tfAdresse.getText() + "','" + tfTotal.getText() + "','" + tfRestant.getText() + "','" + tfCoach.getText() + "')";
                executeQuery(query);

                rechercherT();

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information Dialog");
                alert.setHeaderText(null);
                alert.setContentText("un Event est ajouté !");

                alert.showAndWait();
            } else {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Dialog");
                alert.setHeaderText(null);
                alert.setContentText("Ooops, Please enter a correct number in int fields");

                alert.showAndWait();
            }

        }
    }

    public void saif()
    {
        event event = tvevent.getSelectionModel().getSelectedItem();
    }
    @FXML
    public void getItems() {

        event event = tvevent.getSelectionModel().getSelectedItem();

        tfTitre.setText(String.valueOf(event.getTitre()));
        tefDes.setText(String.valueOf(event.getDesE()));
        // tfDate.setValue(Date.valueOf(LocalDate.)   valueOf(event.getDate()));
        tfPrix.setText(String.valueOf(event.getPrix()));
        tfAdresse.setText(String.valueOf(event.getAdresse()));
        tfTotal.setText(String.valueOf(event.getNbrTotal()));
        tfRestant.setText(String.valueOf(event.getNbrRestant()));
        tfCoach.setText(String.valueOf(event.getIdcoach()));

    }

    public static boolean adresse(String text) {
        if (text.matches("^[A-Z a-z 0-9]+$")) {
            return true;
        }
        return false;
    }

    public static boolean DateNullCS(String date) {
        if (date == "") {
            return true;
        }
        return false;
    }

    public static boolean isString(String text) {
        if (text.matches("^[a-zA-Z]+$")) {
            return true;
        }
        return false;
    }

    private void updateRecord() {

        event event = tvevent.getSelectionModel().getSelectedItem();
        System.out.println(event.getIdE());

        if (tfTitre.getText() == "" || tefDes.getText() == "" || tfDate.getValue() == null || tfPrix.getText() == "" || tfAdresse.getText() == "" || tfTotal.getText() == "" || tfRestant.getText() == "" || tfCoach.getText() == "") {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText(null);
            alert.setContentText("Ooops, Your Textfiels(s) is Empty!");

            alert.showAndWait();
        } else {

            if (tfPrix.getText().matches("^[0-9]+$") && tfTotal.getText().matches("^[0-9]+$") && tfRestant.getText().matches("^[0-9]+$") && tfCoach.getText().matches("^[0-9]+$")) {

                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Look, a Confirmation Dialog");
                alert.setContentText("Are you ok with this?");

                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {

                    String query = "UPDATE  evenement SET Titre  = '" + tfTitre.getText() + "', DesEvent = '" + tefDes.getText() + "', DateEvent = '"
                            + tfDate.getValue() + "', Prix = '" + tfPrix.getText() + "', Adresse = '" + tfAdresse.getText() + "', NbrTotal = '" + tfTotal.getText() + "', NbrRestant = '" + tfRestant.getText() + "', idcoach = '" + tfCoach.getText() + "' WHERE IDevent = '" + event.getIdE() + "'";
                    executeQuery(query);

                    rechercherT();
                } else {
                    // ... user chose CANCEL or closed the dialog
                }

            } else {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Dialog");
                alert.setHeaderText(null);
                alert.setContentText("Ooops, Please enter a correct number in int fields");

                alert.showAndWait();
            }
        }
    }

    private void deleteButton() throws SQLException {
        event event = tvevent.getSelectionModel().getSelectedItem();

        System.out.println(event.getIdE());

        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setHeaderText("Look, a Confirmation Dialog");
        alert.setContentText("Are you ok with this?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {

            String query = "DELETE FROM evenement WHERE IDevent =" + event.getIdE() + "";

            executeQuery(query);
            rechercherT();
        } else {
            // ... user chose CANCEL or closed the dialog
        }

        /**
         * Alert alert = new Alert(AlertType.ERROR); alert.setTitle("ERROR:");
         * alert.setHeaderText("No selection was made.");
         * alert.setContentText("You have not selected an item to delete. Please
         * try again."); alert.showAndWait();
         *
         *
         */
    }

    private void executeQuery(String query) {
        Connection conn = getConnection();

        Statement st;
        try {
            st = conn.createStatement();
            st.executeUpdate(query);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @FXML
    private void Vavis(ActionEvent event) throws IOException {

        Stage stage = new Stage();
        Parent root;
        //stage = (Stage) btn1.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("Vavis.fxml"));
        stage.setScene(new Scene(root));
        stage.initOwner(btnavis.getScene().getWindow());
        stage.showAndWait();

    }

    @FXML
    private void back(ActionEvent event) throws IOException {
        Stage stage;
        Parent root;

        stage = (Stage) fxBack.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("login.fxml"));

        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public static void sendMail(String recepient) throws Exception {
        System.out.println("Preparing to send email");
        Properties properties = new Properties();

        //Enable authentication
        properties.put("mail.smtp.auth", "true");
        //Set TLS encryption enabled
        properties.put("mail.smtp.starttls.enable", "true");
        //Set SMTP host
        properties.put("mail.smtp.host", "smtp.gmail.com");
        //Set smtp port
        properties.put("mail.smtp.port", "587");

        //Your gmail address
        String myAccountEmail = "saif.kridane@gmail.com";
        //Your gmail password
        String password = "Kridenesoufi*";

        //Create a session with account credentials
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(myAccountEmail, password);
            }
        });

        //Prepare email message
        Message message = prepareMessage(session, myAccountEmail, recepient);

        //Send mail
        Transport.send(message);
        System.out.println("Message sent successfully");
    }

    private static Message prepareMessage(Session session, String myAccountEmail, String recepient) {
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(myAccountEmail));
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(recepient));
            message.setSubject("Avis recu");
            String htmlCode = "<h1> Merci pour votre feedback </h1> <br/> <h2><b> ton feedback est transfere a l'equipe, Merci et a tres bientot </b></h2>";
            message.setContent(htmlCode, "text/html");
            return message;
        } catch (Exception ex) {
            Logger.getLogger(EventController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

}
