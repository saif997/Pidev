 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import com.mysql.cj.xdevapi.PreparableStatement;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author saif_kridane
 */
public class LoginController implements Initializable {

    @FXML
    private PasswordField txtpass;
    @FXML
    private TextField txtuname;
    @FXML
    private Button btnok;

    Connection conn;
    
    PreparedStatement pst;
    ResultSet rs;
    @FXML
    private ImageView imageV;
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
     
        // TODO
    }    

    @FXML
    private void login(ActionEvent event) throws SQLException {
     
        
        String uname = txtuname.getText();
        String pass = txtpass.getText();
        
        if(uname.equals("") && pass.equals(""))
        {
        

Alert alert = new Alert(AlertType.ERROR);
alert.setTitle("Error Dialog");
alert.setHeaderText(null);
alert.setContentText("Ooops, Username or password Blank!");

alert.showAndWait();

        }
        else 
        {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pidev", "root","root");
            pst = conn.prepareStatement("select * from login where username=? and password=?");
            pst.setString(1, uname);
            pst.setString(2, pass);
            rs = pst.executeQuery();
            if(rs.next())
            {
                Stage stage;
                Parent root;
                
                stage = (Stage) btnok.getScene().getWindow();
                if(uname.equals("saif") )
                try {
                    
                    root = FXMLLoader.load(getClass().getResource("event.fxml"));
                    
                    
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();
                }
                
                catch (IOException ex) {
                    Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                }
                else 
                {
                       try {
                    
                    root = FXMLLoader.load(getClass().getResource("Entity2.fxml"));
                    
                    
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();
                }
                
                catch (IOException ex) {
                    Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                }
                }
                
            }
            
            else
            {
            
Alert alert = new Alert(AlertType.ERROR);
alert.setTitle("Error Dialog");
alert.setHeaderText(null);
alert.setContentText("Ooops, Username or password is Wrong!");

alert.showAndWait();
            }
            txtuname.setText("");
            txtpass.setText("");
            txtuname.requestFocus();
            ;
        }
    }
    
}
