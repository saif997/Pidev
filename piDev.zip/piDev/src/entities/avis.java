/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author saif_kridane
 */
public class avis {
     private String titre;
    private String typeAvis;
    private String DateE;
    private int note;
    private String nomClient;
    private String email;
    private String Des;
    private int idAvis;
    
    

    public avis(String titre, String typeAvis, String DateE, int note, String nomClient, String email, String Des, int idAvis) {
        this.titre = titre;
        this.typeAvis = typeAvis;
        this.DateE = DateE;
        this.note = note;
        this.nomClient = nomClient;
        this.email = email;
        this.Des = Des;
        this.idAvis = idAvis;
        
    }
    
    public avis()
    {
        
    }

    public String getTitre() {
        return titre;
    }

    public String getTypeAvis() {
        return typeAvis;
    }

    public String getDateE() {
        return DateE;
    }

    public int getNote() {
        return note;
    }

    public String getNomClient() {
        return nomClient;
    }

    public String getEmail() {
        return email;
    }
public String getDes() {
        return Des;
    }
    public int getIdAvis() {
        return idAvis;
    }
    
    

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public void setTypeAvis(String typeAvis) {
        this.typeAvis = typeAvis;
    }

    public void setDateE(String DateE) {
        this.DateE = DateE;
    }

    public void setNote(int note) {
        this.note = note;
    }

    public void setNomClient(String nomClient) {
        this.nomClient = nomClient;
    }

    public void setEmail(String email) {
        this.email = email;
    }
public void setDes(String Des) {
        this.Des = Des;
    }
    public void setIdAvis(int idAvis) {
        this.idAvis = idAvis;
    }

    @Override
    public String toString() {
        return "avis{" + "titre=" + titre + ", typeAvis=" + typeAvis + ", DateE=" + DateE + ", note=" + note + ", nomClient=" + nomClient + ", email=" + email + ", Des=" + Des + ", idAvis=" + idAvis + '}';
    }
    
    
}


